#include "head.h"

int save(hash *hash, char *file)
{
    // Open the file in write mode
    FILE *fptr = fopen(file, "w");
    if (fptr == NULL)
    {
        // Print an error message if the file cannot be opened
        printf("ERROR: Unable to open file %s\n", file);
        return FAILURE;
    }

    // Write data from the hash table to the file
    int flag = 0;
    for (int i = 0; i < 27; i++)
    {
        // Check if there is any data at this index
        if (hash[i].hlink != NULL)
        {
            flag = 1;

            // Iterate over the linked list of main_ structures
            main_ *maintemp = hash[i].hlink;
            while (maintemp != NULL)
            {
                // Write the index, word, and sub structures to the file
                fprintf(fptr,"%s%d;","#",i);
                fprintf(fptr,"%s;%d;",maintemp->word,maintemp->file_count);
                sub *subtemp = maintemp->sublink;
                while(subtemp != NULL)
                {
                    fprintf(fptr,"%s;%d;",subtemp->fname,subtemp->word_count);
                    subtemp = subtemp->sub_link;
                }
                maintemp = maintemp->main_link;
                if(maintemp == NULL)
                {
                    fprintf(fptr,"%s","#");
                }
                else{
                    fprintf(fptr,"%s","#");
                    fprintf(fptr,"%s","\n");
                }
            }
            
            fprintf(fptr,"%s","\n");
        }
    }
    fclose(fptr);
    // Return failure if no data was written to the file
    if (flag == 0)
    {
        return FAILURE;
    }
    else
        // Return success if data was written to the file
        return SUCCESS;
}
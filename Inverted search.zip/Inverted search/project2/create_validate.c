#include "head.h"

int create_validate(hash *h, char *str, Slist **head)
{
    // Check if the file is already in the hash table
    int i;
    for (i = 0; i < 27; i++)
    {
        if (h[i].hlink != NULL)
        {
            main_ *mtemp = h[i].hlink;
            while (mtemp != NULL)
            {
                sub *stemp = mtemp->sublink;
                while (stemp != NULL)
                {
                    // Check if the file name matches
                    if (strcmp(stemp->fname, str) == 0)
                        return FAILURE;
                    stemp = stemp->sub_link;
                }
                mtemp = mtemp->main_link;
            }
        }
    }

    // Create a new Slist node for the file
    Slist *new = malloc(sizeof(Slist));
    if (new == NULL)
        return FAILURE;
    strcpy(new->fname, str);
    new->link = NULL;

    // Add the new node to the Slist
    if (*head == NULL)
    {
        *head = new;
        return SUCCESS;
    }
    Slist *temp = *head;
    while (temp->link != NULL)
    {
        // Check if the file name already exists in the Slist
        if (strcmp(temp->fname, str) == 0)
        {
            free(new);
            return FAILURE;
        }
        temp = temp->link;
    }
    temp->link = new;
    return SUCCESS;
}
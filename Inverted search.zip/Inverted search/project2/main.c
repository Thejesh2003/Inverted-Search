#include "head.h"

/*Documentation
Name : S R Thejesh
Date : 16 February 2025
Title : Inverted Search
Description : This program is used to create a database of text files and search for a word in the database.
*/

int create_flag = 0 , restore_flag = 0 , create_flag2 = 0;

int validate(Slist **head, char *str)
{
    if(strstr(str,".txt") == 0)
    {
        printf("ERROR : %s Not a text file\n", str);
        return FAILURE;
    }
    if(fopen(str,"r") == NULL)
    {
        printf("ERROR : %s File not found\n", str);
        return FAILURE;
    }
    char c;
    if(fscanf(fopen(str,"r"),"%c",&c) == EOF)
    {
        printf("ERROR : %s File Empty\n", str);
        return FAILURE;
    }        
    return SUCCESS;
}

int create_hash(hash *h)
{
    for(int i=0;i<27;i++)
    {
        h[i].index = i;
        h[i].hlink = NULL;
    }
    return SUCCESS;
}


int main(int argc, char **argv)
{
    // Check if enough command-line arguments are provided
    if(argc < 2)
    {
        printf("ERROR : Not enough arguments\n");
        return FAILURE;
    }

    int flag = 0;
    // Initialize hash table and linked lists
    Slist *head = NULL;
    hash arr[27];
    sub *sub_head = NULL;
    main_ *main_head = NULL;

    //Create Hash Table
    create_hash(arr);

    // Validate and process command-line arguments
    for(int i=1;i<argc;i++)
    {
        if(validate(&head , argv[i]) == SUCCESS)
        {
            if(create_validate(arr , argv[i] , &head) == SUCCESS)
            {                
                flag = 1;
            }
        }
    }

    // Check if any files were successfully processed
    if(flag == 0)
    {
        printf("ERROR : FILES not Supported\n");
        return FAILURE;
    }
    else{
        create_flag = 0;
        restore_flag = 0;
        create_flag2 = 0;
    }

    print_list(head);
    
    //Main Menu loop
    do{
        printf("\n1. Create Database\n2. Display Database\n3. Search Database\n4. Save Database\n5. Update Database\n6. Exit\n");
        int ch;
        printf("Enter choice : ");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1://Create Database
                Slist *temp = head;
                if(temp != NULL)
                {
                    create_flag == 0;
                    restore_flag == 0;
                }
                if(create_flag == 0 || create_flag2 == 0)
                {                    
                    if(restore_flag == 0 || create_flag2 == 0)
                    {
                        if(create1(arr , &sub_head , &main_head , head) == FAILURE)
                        {
                            printf("ERROR : Database not created\n");                    
                        }
                        else
                        {
                            create_flag = 1;
                            restore_flag = 1;
                            create_flag2 = 1;
                            printf("Database created successfully\n");                                        
                        }
                    }
                    
                }
                else
                {
                    printf("ERROR : Database already created\n");
                }
                break;

            case 2://Display Database
                flag = 0;
                for(int i=0;i<27;i++)
                {
                    if(arr[i].hlink != NULL)
                    {
                        flag = 1;
                        break;
                    }                        
                }
                if(flag == 1)
                {
                    if(display(arr,main_head,sub_head) == FAILURE)
                        printf("ERROR : Database is EMPTY\n");
                }
                else{
                    printf("ERROR : Database is EMPTY\n");
                }
                break;

            case 3://Search Database
                flag = 0;
                for(int i=0;i<27;i++)
                {
                    if(arr[i].hlink != NULL)
                    {
                        flag = 1;
                        break;
                    }                        
                }
                if(flag == 1)
                {
                    printf("Enter the data to be searched : ");
                    char string[10];
                    scanf("%s",string);
                    if(search(arr , string) == DATA_NOT_FOUND)
                        printf("ERROR : Data not Found\n");
                }
                else{
                    printf("ERROR : Database is EMPTY\n");
                }
                break;

            case 4://Save Database
                if(create_flag == 0 || create_flag2 == 0)
                {
                    printf("ERROR : Database cannot be saved because database is EMPTY\n");
                }
                else{
                    printf("Enter the file name to save : ");
                    char filename[20];
                    do{
                        scanf("%s",filename);
                        if(strstr(filename,".txt") == 0)
                        {
                            printf("ERROR : %s Not a text file\n", filename);
                            printf("Enter the filename with .txt extension : ");
                        }
                        else   break;
                    }while(1);
                    if(save(arr , filename) == FAILURE)
                    {
                        printf("ERROR : Data not saved\n");
                    }
                    else
                    {
                        printf("Data saved successfully in %s\n",filename);
                    }
                }
                break;

            case 5://Update Database
                if(create_flag == 0)
                {
                    if(restore_flag == 0)
                    {
                        printf("Enter the saved file to restore : ");
                        char file[30];
                        do{
                            scanf("%s",file);
                            if(strstr(file,".txt") == 0)
                            {
                                printf("ERROR : %s Not a text file\n", file);
                                printf("Enter the filename with .txt extension : ");
                            }
                            else   break;
                        }while(1);
                        if(restore(arr , file) == FAILURE)
                        {
                            printf("ERROR : Data not restored\n");
                        }
                        else
                        {
                            restore_flag = 1;
                            create_flag = 1;
                            printf("Data restored successfully\n");
                        }
                    }
                    
                }
                else{
                    printf("ERROR : Database cannot be restored as it is already created or restored\n");
                }
                break;

            case 6:
                return SUCCESS; 
        }
        
    }while(1);

}

void print_list(Slist *head)
{
	if (head == NULL)
	{
		printf("INFO : List is empty\n");
	}
    else
    {
	    while (head)		
	    {
		    printf("%s -> ", head -> fname);
		    head = head -> link;
	    }

	    printf("NULL\n");
    }
}
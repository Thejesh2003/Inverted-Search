#include "head.h"

int create1(hash* h, sub** snode, main_** mnode, Slist* head)
{
    Slist *temp = head;
    
    while(temp != NULL)
    {
        int i = 0 , j = 0;
        FILE *fptr = fopen(temp->fname , "r");
        if (fptr == NULL) {
            printf("ERROR: Unable to open file %s\n", temp->fname);
            return FAILURE;
        }

        char str[1024] ;
        int  c;
        while((c = fgetc(fptr)) != EOF)
        {
            str[i++] = c;
        }
        str[i] = '\0';
        //printf("%s\n",str);
        
        char *str1 = strtok(str , " ");
        while(str1 != NULL)
        {
            if(create2(str1 , h , snode , mnode , temp->fname) == FAILURE)
            {
                return FAILURE;
            }
            //printf("%s\n", str1);
            str1 = strtok(NULL , " ");
        }
        fclose(fptr);
        temp = temp->link;
    }
    return SUCCESS;
}

int create2(char *str , hash* h, sub** snode, main_** mnode, char *file)
{
    int index;
    if(isalpha(str[0]))
    {
        if(isupper(str[0]))
            index = str[0] - 'A';
        else
            index = str[0] - 'a';
    }
    else
        index = 26;

    if(h[index].hlink == NULL)
    {
        sub *snew = malloc(sizeof(sub));
        if(snew == NULL)
            return FAILURE;
        
        snew->word_count = 1;
        strcpy(snew->fname , file);
        snew->sub_link = NULL;

        main_ *mnew = malloc(sizeof(main_));
        if(mnew == NULL)
            return FAILURE;

        mnew->file_count = 1;
        strcpy(mnew->word , str);
        mnew->main_link = NULL;
        mnew->sublink = snew;

        h[index].hlink = mnew;
        return SUCCESS;
    }
    else{
        main_ *main_temp = h[index].hlink;
        main_ *mainprev = NULL;
        while(main_temp != NULL)
        {
            if(!(strcmp(main_temp->word , str)))
            {
                sub *sub_temp = main_temp->sublink;
                sub *subprev = NULL;
                while(sub_temp != NULL)
                {
                    if(!(strcmp(sub_temp->fname , file)))
                    {
                        sub_temp->word_count++;
                        //main_temp->file_count++;
                        return SUCCESS;
                    }
                    subprev = sub_temp;
                    sub_temp = sub_temp->sub_link;
                }
                sub *snew = malloc(sizeof(sub));
                if(snew == NULL)
                    return FAILURE;
                
                snew->word_count = 1;
                strcpy(snew->fname , file);
                snew->sub_link = NULL;
                subprev->sub_link = snew;
                main_temp->file_count++;
                return SUCCESS;
            }
            mainprev = main_temp;
            main_temp = main_temp->main_link;
        }
        sub *snew = malloc(sizeof(sub));
        if(snew == NULL)
            return FAILURE;
        
        snew->word_count = 1;
        strcpy(snew->fname , file);
        snew->sub_link = NULL;

        main_ *mnew = malloc(sizeof(main_));
        if(mnew == NULL)
            return FAILURE;

        mnew->file_count = 1;
        strcpy(mnew->word , str);
        mnew->main_link = NULL;
        mnew->sublink = snew;
        mainprev->main_link = mnew;
        return SUCCESS;
    }
}
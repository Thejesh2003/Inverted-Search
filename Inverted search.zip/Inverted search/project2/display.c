#include "head.h"

int display(hash* hash, main_* m, sub* s)
{
    // Print the header for the display
    printf("----------------------------------------------------------------------------\n");
    printf("%7s %10s %15s %16s %14s\n","INDEX","WORD","FILE COUNT","FILENAME","WORD COUNT");
    printf("----------------------------------------------------------------------------\n");

    // Iterate over the hash table
    for(int i=0;i<27;i++)
    {
        // Check if there is any data at this index
        if(hash[i].hlink != NULL)
        {
            // Print the index and a space for formatting
            printf("%2s"," ");
            printf("[%2d] ",i);

            // Iterate over the linked list of main_ structures
            main_ *temp = hash[i].hlink;
            while(temp != NULL)
            {
                // Print the word and file count
                printf("%11s ",temp->word);
                printf("%10d ",temp->file_count);

                // Iterate over the linked list of sub structures
                sub *temp2 = temp->sublink;
                while(temp2 != NULL)
                {
                    // Print the filename and word count
                    printf("%20s ",temp2->fname);
                    printf("%10d ",temp2->word_count);
                    temp2 = temp2->sub_link;
                }                
                printf("\n       ");
                temp = temp->main_link;
            }
            printf("\n");
        }
    }

    // Return success if any data was displayed
    return SUCCESS;
}
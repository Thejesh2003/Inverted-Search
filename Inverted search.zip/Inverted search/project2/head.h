#ifndef HEAD_H
#define HEAD_H

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

#define SUCCESS 1
#define FAILURE 0
#define DATA_NOT_FOUND -1

typedef struct sub_t
{
    int word_count;
    char fname[50];
    struct sub_t *sub_link;
}sub;

typedef struct main_t
{
    int file_count;
    char word[50];
    struct main_t *main_link;
    struct sub *sublink;
}main_;

typedef struct hash_t
{
    int index;
    struct main *hlink;
}hash;

typedef struct list_t
{
    char fname[50];
    struct list_t *link;
}Slist;

int create_hash(hash *);
int create_sub(sub **);
int create_main(main_ **);

int main(int , char**);

int validate(Slist** , char*);

int create_validate(hash* , char* , Slist**);

void print_list(Slist*);

int create1(hash* , sub** , main_** , Slist*);

int create2(char* , hash* , sub** , main_** , char*);

int display(hash* , main_* , sub*);

int search(hash* , char*);

int save(hash* , char*);

int restore(hash* , char*);

#endif
#include "head.h"

int restore(hash *hash , char *file)
{
    FILE *fptr = fopen(file , "r");
    if(fptr == NULL)
    {
        printf("ERROR: Unable to open file %s\n", file);
        return FAILURE;
    }
    char ch1 , ch2;
    fread(&ch1 , sizeof(char) , 1 , fptr);
    fseek(fptr , -1 , SEEK_END);
    fread(&ch2 , sizeof(char) , 1 , fptr);
    if(ch1 != '#' && ch2 != '#'){
        fclose(fptr);
        return FAILURE;
    }
    int index , fcount = 0;
    char word[30];
    rewind(fptr);
    while(fscanf(fptr , "#%d;%[^;];%d;" , &index , word , &fcount) == 3)
    {
        main_ *mnew = malloc(sizeof(main_));
        if(mnew == NULL)
            return FAILURE;
        mnew->file_count = fcount;
        strncpy(mnew->word, word, sizeof(mnew->word) - 1);
        mnew->word[sizeof(mnew->word) - 1] = '\0';
        mnew->main_link = NULL;
        mnew->sublink = NULL;

        int wcount = 0;
        char file[50];
        sub *prev = NULL;
        for(int i=0;i<fcount;i++)
        {
            fscanf(fptr , "%[^;];%d;" , file , &wcount);
            sub *snew = malloc(sizeof(sub));
            if(snew == NULL)
                return FAILURE;
            strncpy(snew->fname, file, sizeof(snew->fname) - 1);
            snew->fname[sizeof(snew->fname) - 1] = '\0';
            snew->word_count = wcount;
            snew->sub_link = NULL;
            if(prev == NULL)
            {
                mnew->sublink = snew;
            }
            else
            {
                prev->sub_link = snew;
            }
            prev = snew;
        }
        if(hash[index].hlink == NULL) {
            hash[index].hlink = mnew;
        } else {
            main_ *mtemp = hash[index].hlink;
            while(mtemp->main_link != NULL) {
                mtemp = mtemp->main_link;
            }
            mtemp->main_link = mnew;
        }
        fscanf(fptr, "#\n");
    }
    fclose(fptr);
    return SUCCESS;
}
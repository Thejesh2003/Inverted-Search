#include "head.h"

int search(hash* hash, char *data)
{
    // Calculate the index based on the first character of the data
    int index;
    if(isalpha(data[0])) // Check if the first character is a letter
    {
        if(isupper(data[0])) // Check if the letter is uppercase
            index = data[0] - 'A'; // Convert to index (0-25)
        else
            index = data[0] - 'a'; // Convert to index (0-25)
    }
    else
    {
        index = 26; // Special case for non-letter characters
    }

    // Check if the index is valid
    if(hash[index].hlink == NULL)
        return DATA_NOT_FOUND; // Return failure if no data at this index

    // Search for the data in the linked list
    main_ *maintemp = hash[index].hlink;
    while(maintemp != NULL)
    {
        // Compare the data with the current node's word
        if(strcmp(maintemp->word , data) == 0)
        {
            // Print the results if a match is found
            printf("\n%s present in %d files\n",data,maintemp->file_count);
            sub *subtemp = maintemp->sublink;
            while(subtemp != NULL)
            {
                printf("%s for %d times\n",subtemp->fname , subtemp->word_count);
                subtemp = subtemp->sub_link;
            }
            return SUCCESS; // Return success if data is found
        }
        maintemp = maintemp->main_link; // Move to the next node in the list
    }

    // Return failure if no match is found
    return DATA_NOT_FOUND;
}